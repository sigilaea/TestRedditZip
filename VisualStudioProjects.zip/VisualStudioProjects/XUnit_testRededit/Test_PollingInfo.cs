using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.Extensions;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Routing;
using Microsoft.Extensions.Configuration;
using Moq;
using Moq.Protected;
using Reddit;
using System.Net.Http;
using System.Net;
using System.Security.Principal;
using TestReddit.Controllers;
using TestReddit.Interfaces;
using TestReddit.Repositories;
using uhttpsharp;
using Newtonsoft.Json.Linq;

namespace XUnit_testRededit
{
    public class Test_PollingInfo
    {
        private readonly Mock<IPolling> _pollingInfo;
        private readonly Mock<IConfiguration> _config;
        private readonly Mock<IRedditSubInfo> _subInfo;
        private readonly Mock<IResponseMessage> _responseMessage;
        private readonly Mock<IJObject> _jObject;
        private readonly Mock<RedditClient> _redditClient;

        private readonly string _code = "tRFlSdYIpk-QUm9VewC-HwW5G-UeyQ";
        private readonly string _authorizeCallbackUrl = "http://127.0.0.1:5074/authorize_callback?state=iqdjzxog&code=tRFlSdYIpk-QUm9VewC-HwW5G-UeyQ";
        bool _isSuccessful = true;
        

        public Test_PollingInfo()
        {
            _pollingInfo = new Mock<IPolling>();
            _config = new Mock<IConfiguration>();
            _subInfo = new Mock<IRedditSubInfo>();
            _responseMessage = new Mock<IResponseMessage>();
            _jObject = new Mock<IJObject>();
            _redditClient = new Mock<RedditClient>();
        }

        [Fact]
        public void TestAuthorizeCallBack()
        {
            _pollingInfo.Setup(a => a.GetDisplayUrl(It.IsAny<HttpContext>())).Returns(_authorizeCallbackUrl);
            _pollingInfo.Setup(x => x.GetRedditSubInfo(It.IsAny<string>())).ReturnsAsync(_isSuccessful);

            var testController = new TestRedditController(_config.Object, _pollingInfo.Object);
            var successfulRun = testController.authorize_callback();

            Assert.NotNull(successfulRun);
            Assert.True(successfulRun.Result.Equals("Process finished with no errors."));
        }

        [Fact]
        public void TestGetRedditSubInfo()
        {
            HttpResponseMessage mr = new HttpResponseMessage();
            _responseMessage.Setup(s => s.GetTokenResponseMessage(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>())).Returns(Task.FromResult(mr));
            
            _subInfo.Setup(a => a.GetSubInfo(It.IsAny<RedditClient>(), It.IsAny<string>())).Returns(Task.FromResult(true));
            _config.SetupGet(a => a[It.Is<string>(b => b == "Reddit:RedirectUri")]).Returns("http://127.0.0.1:5074/authorize_callback");
            _config.SetupGet(c => c[It.Is<string>(d => d == "Reddit:ClientId")]).Returns("V_La8vcNcRUJPF4W-b14wQ");
            _config.SetupGet(e => e[It.Is<string>(f => f == "Reddit:ClientSecret")]).Returns("aPlFw5IUvipoU8NvM76HP2PBQTgoxQ");
            _config.SetupGet(g => g[It.Is<string>(h => h == "Reddit:UserAgent")]).Returns("ThisIsMyUserAgent/1.0 by you_should_hire_me");
            _config.SetupGet(i => i[It.Is<string>(j => j == "Reddit:RefreshToken")]).Returns("61292553135146-1ZclbkqCutOz8DdQNUXEAyXRlGmjpg");
            _config.SetupGet(k => k[It.Is<string>(l => l == "RateLimitRequestPerMinute")]).Returns("20");
            _config.SetupGet(m => m[It.Is<string>(n => n == "MaxAttemptsPerSecond")]).Returns("2");
            _config.SetupGet(o => o[It.Is<string>(p => p == "Reddit:AccessTokenUrl")]).Returns("https://www.reddit.com/api/v1/access_token/");
            _config.SetupGet(q => q[It.Is<string>(r => r == "Reddit:SubReddit")]).Returns("cfb");

            _jObject.Setup(t => t.GetAccessTokenFromContent(It.IsAny<string>())).Returns("eyJhbGciOiJSUzI1NiIsImtpZCI6IlNIQTI1NjpzS3dsMnlsV0VtMjVmcXhwTU40cWY4MXE2OWFFdWFyMnpLMUdhVGxjdWNZIiwidHlwIjoiSldUIn0.eyJzdWIiOiJ1c2VyIiwiZXhwIjoxNjk3NDcxMjEzLjYwNjU1MSwiaWF0IjoxNjk3Mzg0ODEzLjYwNjU1MSwianRpIjoibS1SaUpnd2QwWXNZd1dPdlFxM2pJTHlWaEQ2TUFnIiwiY2lkIjoiVl9MYTh2Y05jUlVKUEY0Vy1iMTR3USIsImxpZCI6InQyX2xxNWVybHljcSIsImFpZCI6InQyX2xxNWVybHljcSIsImxjYSI6MTY5NzI1MjcyMjgyOCwic2NwIjoiZUp5S1ZpcEtUVXhSaWdVRUFBRF9fd3ZFQXBrIiwicmNpZCI6IlN3el9FY2g2OF9ycERoVEFoeld6ak9fVVBNcTBwcERYRkU4SDhFMktoYVEiLCJmbG8iOjh9.rXor4OF0W0uqvRHnF8-k5V4DO1UHjseQ_eW3PIj188WzGBZR80DzuJTR9ktAYs29G5NjhQHmBCyR0_KW9o_Qze6g2AtsyBgeIITUNWSJkvDhYvKVUnegX73whHYcTQAJvG1JE1W2Zn3pwPWJoEAOIDsmOZusCy9Ro_YATTwmERbIozJGa2APwUCAHbu0um0mV1RZZZFbJI4Fk7FE0V0gUlfGimGvz8t1SbefkWmhxofYFbnh9MaJXNm7IQ7TjEk1xI5r8Jwwpp0nmX9ztSXdYC0Th3F8d8OCgklNqsCs7fhSpca6ZGGDq4OFeFF1mhWIs04vRkhthnf6qHUOK9dbZA");
            var polling = new Polling(_subInfo.Object, _config.Object, _responseMessage.Object, _jObject.Object);
            var successfulRun = polling.GetRedditSubInfo(_code);

            Assert.NotNull(successfulRun);
            Assert.True(successfulRun.Result.Equals(true));

        }

    }

    
}