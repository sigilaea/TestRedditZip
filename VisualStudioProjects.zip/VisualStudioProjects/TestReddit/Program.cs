using log4net;
using System.Reflection;
using TestReddit.Interfaces;
using TestReddit.Repositories;

var builder = WebApplication.CreateBuilder(args);
log4net.ILog _log = LogManager.GetLogger(typeof(Program));

builder.Services.AddCors(options =>
{
    options.AddDefaultPolicy(builder =>
    {
        builder.AllowAnyOrigin()
               .AllowAnyMethod()
               .AllowAnyHeader();
    });
});


var config = builder.Configuration;
config.SetBasePath(AppDomain.CurrentDomain.BaseDirectory)
    .AddJsonFile("appsettings.json")
    .Build();

builder.Services.AddHttpClient("HttpRedditClient", client =>
{
    client.BaseAddress = new Uri(config["Reddit:AccessTokenUrl"]);
    client.DefaultRequestHeaders.Add("Authorization", $"Basic {Convert.ToBase64String(System.Text.Encoding.UTF8.GetBytes($"{config["Reddit:ClientId"]}:{config["Reddit:ClientSecret"]}"))}");
    client.DefaultRequestHeaders.Add("User-Agent", config["Reddit:UserAgent"]);
});


builder.Services.AddControllers();
builder.Services.AddSwaggerGen();

builder.Services.AddScoped<IRedditSubInfo, RedditSubInfo>(); //dependency injection
builder.Services.AddScoped<IPolling, Polling>(); //dependency injection
builder.Services.AddScoped<IResponseMessage, ResponseMessage>(); //dependency injection
builder.Services.AddScoped<IJObject, JObjectRepo>(); //dependency injection


var app = builder.Build();
app.UseHttpsRedirection();
app.UseRouting();

app.UseCors();

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseAuthorization();
app.MapControllers();

Setuplogging();
_log.Info("Application Configured");

app.Run();


void Setuplogging()

{
    var l4n = config.GetSection("log4net").Value;
    System.Xml.XmlDocument log4netConfig = new System.Xml.XmlDocument();
    log4netConfig.LoadXml(l4n);
    var repo = LogManager.CreateRepository(Assembly.GetEntryAssembly(), typeof(log4net.Repository.Hierarchy.Hierarchy));
    log4net.Config.XmlConfigurator.Configure(repo, log4netConfig["log4net"]);
    _log.Info("Logging Configured");
}