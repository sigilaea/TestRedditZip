﻿namespace TestReddit.Interfaces
{
    public interface IPolling
    {
        public Task<bool> GetRedditSubInfo(string code);
        public string GetDisplayUrl(HttpContext httpContext);
    }
}
