﻿namespace TestReddit.Interfaces
{
    public interface IJObject
    {
        public string GetAccessTokenFromContent(string content);
    }
}
