﻿using Reddit;

namespace TestReddit.Interfaces
{
    public interface IRedditSubInfo
    {
        public Task<bool> GetSubInfo(RedditClient reddit, string subRedditor);
    }
}
