﻿namespace TestReddit.Interfaces
{
    public interface IResponseMessage
    {
        public Task<HttpResponseMessage> GetTokenResponseMessage(string tokenUrl, string code, string redirectUri);
    }
}
