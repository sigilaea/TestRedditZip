﻿using log4net;
using Reddit;
using Reddit.Inputs;
using TestReddit.Interfaces;

namespace TestReddit.Repositories
{
    public class RedditSubInfo : IRedditSubInfo
    {
        private static readonly ILog _log = LogManager.GetLogger(typeof(RedditSubInfo));
        public async Task<bool> GetSubInfo(RedditClient reddit, string subReddit)
        {
            bool isSuccess = true;

            _log.Info($"START - Getting Users and Posts counts.----------------------------------");
            try
            {
                Reddit.Controllers.Subreddit sr = reddit.Subreddit(subReddit).About();
                //Posts with most up votes
                var topUpvotes = sr.Posts.GetTop().MaxBy(x => x.UpVotes);
                _log.Info($"Post with highest upvotes belongs to: {topUpvotes.Author}. UpVotes: {topUpvotes.UpVotes.ToString()}\r\n");//author

                //Users with most posts
                var posts = sr.Posts.GetTop(new TimedCatSrListingInput(t: "day", limit: 10));
                _log.Info($"Top 10 Users with the most post belongs to:");
                foreach (var post in posts)
                {
                    _log.Info($"User: {post.Author}. Post Count: {post.Score.ToString()}");
                }
            }
            catch (Exception ex)
            {
                _log.Error($"Error: {ex.Message}");
            }
            _log.Info($"END - Getting Users and Posts counts.----------------------------------\r\n");
            
            return isSuccess;
        }
    }
}
