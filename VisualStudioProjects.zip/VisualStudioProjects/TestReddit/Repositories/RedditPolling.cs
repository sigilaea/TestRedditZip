﻿using log4net;
using Newtonsoft.Json.Linq;
using Reddit;
using TestReddit.Interfaces;
using Microsoft.AspNetCore.Http.Extensions;

namespace TestReddit.Repositories
{
    
    public class Polling : IPolling
    {
        private static readonly ILog _log = LogManager.GetLogger(typeof(RedditSubInfo));
        IRedditSubInfo _subRedditRepo;
        IConfiguration _config;
        IResponseMessage _responseRepo;
        IJObject _jObject;
        public Polling(IRedditSubInfo subreddit, 
                             IConfiguration configuration,
                             IResponseMessage responsemessage,
                             IJObject jObject)
        {
            _subRedditRepo = subreddit;
            _config = configuration;
            _responseRepo = responsemessage;
            _jObject = jObject; 
        }
        public async Task<bool> GetRedditSubInfo(string code)
        {
            bool isSuccessful = true;

            try
            {
                string? redirectUri = _config["Reddit:RedirectUri"];
                string? clientId = _config["Reddit:ClientId"];
                string? clientSecret = _config["Reddit:ClientSecret"];
                string? userAgent = _config["Reddit:UserAgent"];
                string? refreshToken = _config["Reddit:RefreshToken"];
                string? rateLimit = _config["RateLimitRequestPerMinute"];
                string? maxAttempts = _config["MaxAttemptsPerSecond"];
                int requestsPerMinute = int.Parse(rateLimit);
                int parallelAttempts = int.Parse(maxAttempts);
                var tasks = new Task[parallelAttempts];
                string? tokenUrl = _config["Reddit:AccessTokenUrl"];
                string? subReddit = _config["Reddit:SubReddit"];

                var response = await _responseRepo.GetTokenResponseMessage(tokenUrl, code, redirectUri);
                if (response.IsSuccessStatusCode)
                {
                    string? content = await response.Content.ReadAsStringAsync();
                    string? accessToken = _jObject.GetAccessTokenFromContent(content);

                    _log.Info($"Getting information for subReddit: {subReddit}");
                    RedditClient reddit = new RedditClient(clientId, refreshToken, clientSecret, accessToken, userAgent);

                    for (int second = 0; second < requestsPerMinute; second++)
                    {
                        try
                        {
                            _log.Info($"Sending parallel request {second + 1} of {requestsPerMinute}\r\n");
                            for (int i = 0; i < parallelAttempts; i++)
                            {
                                tasks[i] = _subRedditRepo.GetSubInfo(reddit, subReddit);
                            }
                            await Task.WhenAll(tasks);
                            await Task.Delay(1000);
                        }
                        catch (Exception ex)
                        {
                            _log.Error($"Error - attempt {second} failed: {ex.Message}\r\n");
                            isSuccessful = false;
                        }

                    }
                }
            }
            catch (Exception except)
            {
                _log.Error($"Error: {except.Message}");
                isSuccessful = false;
            }
            return isSuccessful;
        }

        public string GetDisplayUrl(HttpContext httpContext)
        {
            string authCode = null;

            authCode = httpContext.Request.GetDisplayUrl();

            return authCode;
        }
    }
}
