﻿using Newtonsoft.Json.Linq;
using TestReddit.Interfaces;

namespace TestReddit.Repositories
{
    public class JObjectRepo : IJObject
    {
        public string GetAccessTokenFromContent(string content)
        {
            string? token = string.Empty;

            if(content != null)
            {
                token = JObject.Parse(content)["access_token"].Value<string>();
            }
            return token;
        }
    }
}
