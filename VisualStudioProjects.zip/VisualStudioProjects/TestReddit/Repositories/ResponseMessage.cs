﻿using log4net;
using System.Net.Http;
using TestReddit.Interfaces;

namespace TestReddit.Repositories
{
    public class ResponseMessage : IResponseMessage
    {
        private readonly IHttpClientFactory _httpClientFactory;
        private static readonly ILog _log = LogManager.GetLogger(typeof(RedditSubInfo));

        public ResponseMessage(IHttpClientFactory clientfactory)
        {
            _httpClientFactory = clientfactory;
        }

        public async Task<HttpResponseMessage> GetTokenResponseMessage(string tokenUrl, string code ,string redirectUri)
        {
            var httpClient = _httpClientFactory.CreateClient("HttpRedditClient");
            FormUrlEncodedContent tokenRequest = new FormUrlEncodedContent(new[]
            {
                        new KeyValuePair<string, string>("grant_type", "authorization_code"),
                        new KeyValuePair<string, string>("code", code),
                        new KeyValuePair<string, string>("redirect_uri", redirectUri)
                });

            _log.Info("Getting token.");

            //var response = await _httpClientWrapper.PostAsync(tokenUrl, tokenRequest);
            var response = await httpClient.PostAsync(tokenUrl, tokenRequest);
            return response;
        }
    }
}
