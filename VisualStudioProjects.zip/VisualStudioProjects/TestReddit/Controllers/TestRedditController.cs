﻿using Microsoft.AspNetCore.Http.Extensions;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Cors;
using TestReddit.Interfaces;
using log4net;
using TestReddit.Repositories;
using System.Text;

namespace TestReddit.Controllers
{
    [EnableCors]
    [ApiController]
    public class TestRedditController : ControllerBase
    {
        IConfiguration _config;
        IPolling _pollingInfo;
        private static readonly ILog _log = LogManager.GetLogger(typeof(RedditSubInfo));
        public TestRedditController(IConfiguration config, IPolling pollingInfo)
        {
            _config = config;
            _pollingInfo = pollingInfo;
        }

        [HttpGet,Route("/Authorize")]
        public string Authorize()
        {
            var clientId = _config["Reddit:ClientId"];
            var st = RandomString(8, true);
            var redirectUri = _config["Reddit:RedirectUri"];
            var redditAuthUrl = $"https://www.reddit.com/api/v1/authorize?client_id={clientId}&response_type=code&state={st}&redirect_uri={redirectUri}&duration=permanent&scope=read";
            return "Use the following URL in a web browser to approve access to your Reddit apps: \r\n" + redditAuthUrl;
        }

        [HttpGet, Route("/authorize_callback")]
        public async Task<string> authorize_callback()
        {
            bool isSuccessful = true;
            try
            {
                string authCode = _pollingInfo.GetDisplayUrl(HttpContext);
                string[] authCodeArray = authCode.Split('=');
                string code = authCodeArray[authCodeArray.Length - 1];

                if (string.IsNullOrEmpty(code))
                {
                    return "Call back failed."; //message is deliberately vague to slow attackers. Details would be stored in an offsite log using a tool like ELK
                }
                isSuccessful = await _pollingInfo.GetRedditSubInfo(code);
            }
            catch (Exception ex)
            {
                _log.Error($"Error. {ex.Message}");
                isSuccessful = false;
                return "There was an error in processing. Please contact your administrator.";
            }
          
            return isSuccessful == true ? "Process finished with no errors." : "Process finish with errors.";
        }

        private string RandomString(int size, bool lowerCase = false)
        {
            Random _random = new Random();
            var builder = new StringBuilder(size);

            char offset = lowerCase ? 'a' : 'A';
            const int lettersOffset = 26; // A...Z or a..z: length=26

            for (var i = 0; i < size; i++)
            {
                var @char = (char)_random.Next(offset, offset + lettersOffset);
                builder.Append(@char);
            }

            return lowerCase ? builder.ToString().ToLower() : builder.ToString();
        }

    }
}

    

    
